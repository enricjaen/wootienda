=== Tokokoo Extensions ===

Contributors: tokokoo, satrya
Tags: post type, shortcode, custom css, facebook app
License: GPLv2 or later
Requires at least: 3.5
Tested up to: 3.5.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin extends functionality to Tokokoo Themes. It provides a several optional custom post types, custom css, shortcodes, etc.

==Description==

We decided to seperate between core features and extensions features. It's extends functionality to the collection of Tokokoo Themes. It provides a several optional custom post types, custom css, shortcodes, facebook app and customizer functionality.(More descriptions to come)

**Note 1:** This plugin only works with <a href="http://tokokoo.com/tokokoo-themes/">Tokokoo Themes</a>!
**Note 2:** If you already our customer, please DO NOT download and use it before we announce which theme already support it!

== Installation ==

1. Log into your admin page
2. Type "Tokokoo Extensions" into the Search input and click the "Search Plugins" button.
3. Locate the "Tokokoo Extensions" in the list of search results and click "Install Now".
4. Click the "Activate Plugin" link at the bottom of the install screen.
5. The extensions features are automatically activated.

== Frequently Asked Questions ==

= What is this plugin and why do I need it? =

The Tokokoo Extensions provides extra functionality to the collection of Tokokoo Themes. It is required to use Tokokoo themes.

= How do I use it? =

Once you install it, the extensions features are automatically activated.

== Changelog ==

= v1.0 - July 26, 2013 =
* Original Release.